const mineflayer = require('mineflayer');

const bot = mineflayer.createBot({
  host: 'localhost',       // Change this to the IP of the Minecraft server (e.g., 'play.example.com')
  port: 25565,             // Change if your server uses a different port
  username: 'BotEmail@example.com', // Use a real Minecraft account email or username (if cracked mode is enabled on your server)
  // password: 'yourPassword',     // Uncomment this if your account needs a password (e.g., Mojang or Microsoft account)
  version: false           // Auto-detect version
});

bot.on('login', () => {
  console.log(`[✔] Bot has logged in as ${bot.username}`);
});

bot.on('chat', (username, message) => {
  if (username === bot.username) return;
  if (message.toLowerCase() === 'hi') {
    bot.chat(`Hello, ${username}!`);
  }
});

bot.on('kicked', (reason) => {
  console.log(`[KICKED] ${reason}`);
});

bot.on('error', (err) => {
  console.log(`[ERROR] ${err}`);
});